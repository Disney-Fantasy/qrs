// pages/Huawei_IOT.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title:'智能出行助手',
    result:'等待获取token',
    token:'null',
    shadow:'null',
    temp:'',
    tianqi:'',
    fengxiang:'',
    dengji:'',
    humi:'',
    cond_txt:'     晴天',
    tmp:'    33.6°C',
    wind_dir:'  西南风',
    wind_spd:'   2~3级',
    lll:'获取位置',
    inputIp:'117.78.5.125',
    inputPort:'8883',
    out:'      适宜出行',
  },
  gettoken:function(){
    console.log("开始获取......");
    var that=this;
    wx.request({
      url: 'https://iam.cn-north-4.myhuaweicloud.com/v3/auth/tokens',
      data:'{"auth": {"identity": {"methods": ["password"],"password": {"user": {"name": "Sonne1","password": "153729890sun","domain": {"name": "hid_xcvvns4o9uy6nfd"}}}},"scope": {"project": {"name": "cn-north-4"}}}}',
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {'Content-Type':'application/json;charset=utf8'}, // 设置请求的 header 
      success: function(res){// success
      // success
        console.log("获取token成功");
        var token='';
        console.log(res);
        token=JSON.stringify(res.header['X-Subject-Token']);
        token=token.replaceAll("\"","");
        console.log("获取token=\n"+token);
        wx.setStorageSync('token',token);
      },
       fail:function(){
         console.log('获取token失败');
       // fail
      },
       complete: function() {
         console.log("获取token完成");
      // complete
      } 
    });
  },
  touchBtn_gettoken:function()
    {
        console.log("获取token中...");
        this.gettoken();
    },
    /**
     * 获取设备影子按钮按下：
     */
    getshadow:function(){
      console.log("开始获取影子");
      var that=this;
      var token=wx.getStorageSync('token');
      console.log("我的token："+token);
      wx.request({
        url: 'https://f7d1c203b1.st1.iotda-app.cn-north-4.myhuaweicloud.com:443/v5/iot/bcf42ab29d674c2b9cf87ae623c851bf/devices/667d0daf7dbfd46fabc24d19_1349915585/shadow',
        data:'{"auth": {"identity": {"methods": ["password"],"password": {"user": {"name": "Sonne1","password": "153729890sun","domain": {"name": "hid_xcvvns4o9uy6nfd"}}}},"scope": {"project": {"name": "cn-north-4"}}}}',
        method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        header: {'content-type': 'application/json','X-Auth-Token':token }, //请求的header 
        success: function(res){// success
              // success
          var shadow=JSON.stringify(res.data.shadow[0].reported.properties);
          console.log('设备影子数据：'+shadow);
          var ControlModule=JSON.stringify(res.data.shadow[0].reported.properties.ControlModule);
          console.log('ControlModule：'+ControlModule+' Over');
          that.setData({result:'ControlModule:'+ControlModule+' Over'});
          console.log("获取影子成功");
          console.log(res);
        },
        fail:function(){
          console.log("获取影子失败");
          console.log("请先获取token");
        },
        complete:function(){
          console.log("获取影子完成");
        }
      });
    },

  touchBtn_getshadow:function()
  {
    console.log("获取设备影子按钮按下");
    this.setData({result:'获取设备影子按钮按下'});
    this.getshadow();
    },
     /**
     * 设备命令下发按钮按下：
     */
  setCommand:function(){
    console.log("开始下发命令。。。");//打印完整消息
    var that=this;  //这个很重要，在下面的回调函数中由于异步问题不能有效修改变量，需要用that获取
    var token=wx.getStorageSync('token');//读缓存中保存的token
    wx.request({
      url: 'https://f7d1c203b1.st1.iotda-app.cn-north-4.myhuaweicloud.com:443/v5/iot/bcf42ab29d674c2b9cf87ae623c851bf/devices/667d0daf7dbfd46fabc24d19_1349915585/commands',
      data:'{"service_id": "TrafficLight","command_name": "ControlModule","paras": { "TrafficLight: "RED_LED_ON"}}',
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {'content-type': 'application/json','X-Auth-Token':token }, //请求的header 
      success: function(res){// success
              // success
        console.log("下发命令成功");//打印完整消息
        console.log(res);//打印完整消息
          },
      fail:function(){
              // fail
        console.log("命令下发失败");//打印完整消息
        console.log("请先获取token");//打印完整消息
      },
      complete: function() {
              // complete
        console.log("命令下发完成");//打印完整消息
        that.setData({result:'设备命令下发完成'});
        } 
      });
    },
  touchBtn_setCommand:function()
  {
    console.log("设备命令下发按钮按下");
  },
  address:function(){
    console.log("开始获取影子");
    var that=this;
    var token=wx.getStorageSync('token');
    console.log("我的token："+token);
    wx.request({
      url: 'https://f7d1c203b1.st1.iotda-app.cn-north-4.myhuaweicloud.com:443/v5/iot/bcf42ab29d674c2b9cf87ae623c851bf/devices/667d0daf7dbfd46fabc24d19_1349915585/shadow',
      data:'{"auth": {"identity": {"methods": ["password"],"password": {"user": {"name": "Sonne1","password": "153729890sun","domain": {"name": "hid_xcvvns4o9uy6nfd"}}}},"scope": {"project": {"name": "cn-north-4"}}}}',
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {'content-type': 'application/json','X-Auth-Token':token }, //请求的header 
      success: function(res){// success
              // success
        var shadow=JSON.stringify(res.data.shadow[1].reported.properties);
        console.log('设备影子数据：'+shadow);
        //var ControlModule=JSON.stringify(res.data.shadow[0].reported.properties.ControlModule);
        //console.log('ControlModule：'+ControlModule+' Over');
        //that.setData({result:'ControlModule:'+ControlModule+' Over'});
        //console.log("获取影子成功")
        console.log(res);
        var LONGITUDE=JSON.stringify(res.data.shadow[1].reported.properties.LONGITUDE);
        var LATITUDE=JSON.stringify(res.data.shadow[1].reported.properties.LATITUDE);
        console.log('jingweidu：'+LONGITUDE+'and'+LATITUDE+ 'Over');
        //that.setData({result:'ControlModule:'+ControlModule+' Over'});
        LONGITUDE = LONGITUDE.replace(/["']/g, '');
        LATITUDE = LATITUDE.replace(/["']/g, '');
        var long = Number(LONGITUDE);
        var lati = Number(LATITUDE);
        console.log("获取影子成功"+long+'and'+lati);
        console.log(res);
        wx.openLocation({
          longitude:long,//number类型
          latitude:lati,
          scale:18
        })
        },
      fail:function(){
        console.log("获取影子失败");
        console.log("请先获取token");
      },
      complete:function(){
        console.log("获取影子完成");
      }
    });
  },
  touchBtn_address:function()
  {
    console.log("获取地址按下");
    this.address();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})