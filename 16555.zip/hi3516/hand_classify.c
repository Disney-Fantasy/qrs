/*
 * Copyright (c) 2022 HiSilicon (Shanghai) Technologies CO., LIMITED.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * 该文件提供了基于yolov2的手部检测以及基于resnet18的手势识别，属于两个wk串行推理。
 * 该文件提供了手部检测和手势识别的模型加载、模型卸载、模型推理以及AI flag业务处理的API接口。
 * 若一帧图像中出现多个手，我们通过算法将最大手作为目标手送分类网进行推理，
 * 并将目标手标记为绿色，其他手标记为红色。
 *
 * This file provides hand detection based on yolov2 and gesture recognition based on resnet18,
 * which belongs to two wk serial inferences. This file provides API interfaces for model loading,
 * model unloading, model reasoning, and AI flag business processing for hand detection
 * and gesture recognition. If there are multiple hands in one frame of image,
 * we use the algorithm to use the largest hand as the target hand for inference,
 * and mark the target hand as green and the other hands as red.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <sys/prctl.h>

#include "hisignalling.h"
#include "sample_comm_nnie.h"
#include "sample_media_ai.h"
#include "ai_infer_process.h"
#include "yolov2_hand_detect.h"
#include "vgs_img.h"
#include "ive_img.h"
#include "misc_util.h"
#include "audio_aac_adp.h"
#include "posix_help.h"
//#include "mpp_help.h"
//#include "hi_ext_util.h"
//#include "ai_plug.h"
#include "audio_test.h"
#define BUFFER_SIZE1 4


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */
#define PLUG_UUID          "\"hi.hand_classify\""
#define PLUG_DESC          "\"猫狗检测分类(darknet+resnet)\""     // UTF8 encode

#define FRM_WIDTH          640
#define FRM_HEIGHT         384
#define HAND_FRM_WIDTH     640
#define HAND_FRM_HEIGHT    384
#define DETECT_OBJ_MAX     32
#define RET_NUM_MAX        4
#define DRAW_RETC_THICK    2    // Draw the width of the line
#define WIDTH_LIMIT        32
#define HEIGHT_LIMIT       32
#define IMAGE_WIDTH        224  // The resolution of the model IMAGE sent to the classification is 224*224
#define IMAGE_HEIGHT       224

//#define MODEL_FILE_GESTURE    "/userdata/models/hand_classify/five_resnet1_trash_classify_inst.wk" // darknet framework wk model
#define MODEL_FILE_GESTURE    "/userdata/models/hand_classify/hand_detect_inst.wk" // darknet framework wk model

#define AUDIO_CASE_TWO     2
#define AUDIO_SCORE        60		// 置信度可自行配置
#define AUDIO_FRAME        14 		// 每隔15帧识别一次，可自行配置

#define MULTIPLE_OF_EXPANSION 100   // Multiple of expansion
#define UNKOWN_WASTE          20    // Unkown Waste
#define SCORE_MAX           4096    // The score corresponding to the maximum probability
static int g_num = 108;
static int g_count = 0;
#define BUFFER_SIZE           16    // buffer size
static pthread_t g_audioProcessThread = 0;
#define GESTURE_MIN        30   // confidence threshold
static int biggestBoxIndex;
static IVE_IMAGE_S img;

static DetectObjInfo objsBig = {0};
static DetectObjInfo objs[DETECT_OBJ_MAX] = {0};
static RectBox boxs[DETECT_OBJ_MAX] = {0};
static RectBox objBoxs[DETECT_OBJ_MAX] = {0};
static RectBox remainingBoxs[DETECT_OBJ_MAX] = {0};
static RectBox cnnBoxs[DETECT_OBJ_MAX] = {0}; // Store the results of the classification network
static RecogNumInfo numInfo[RET_NUM_MAX] = {0};
static IVE_IMAGE_S imgIn;
static IVE_IMAGE_S imgDst;
static VIDEO_FRAME_INFO_S frmIn;
static VIDEO_FRAME_INFO_S frmDst;
int uartFd = 0;
#define OSD_FONT_WIDTH	   16
#define OSD_FONT_HEIGHT	   24
static OsdSet* g_osdsGesture = NULL;
static HI_S32 g_osd0Gesture = -1;

static HI_BOOL g_bAudioProcessStopSignal = HI_FALSE;

static pthread_t g_thrdId = 0;
static int g_supportAudio = 0;


static HI_CHAR *gesture_name = NULL;

int Flag1 = 0;

static int uart_fd ;

static SkPair g_stmChn = {
    .in = -1,
    .out = -1
};

/*
 * 将识别的结果进行音频播放
 * Audio playback of the recognition results
 */
static int g_obj = 108;
static int g_loa = 108;
static int g_loaa = 108;
static HI_VOID PlayAudio(const DetectObjInfo items)
{
    if  (g_count < AUDIO_FRAME) {
        g_count++;
        return;
    }
    const DetectObjInfo *item = &items;
    int s,t=0;
    s=(item->box.xmax+item->box.xmin)/2;
    t=(item->box.ymax+item->box.ymin)/2;
    if((s>640)&&(s<1280)){
        if(t<=360){
           g_loa=0; //正前方远处
        }
        if((t>360)&&(t<720)){
            g_loa=1;//正前方
        }
        if(t>=720){
            g_loa=2;//正前方很近
        }
    }
    if(s<=640){
        if(t<=360){
           g_loa=3; //左前方远处
        }
        if((t>360)&&(t<720)){
            g_loa=4;//左前方
        }
        if(t>=720){
            g_loa=5;//左前方很近
        }
    }
    if(s>=1280){
        if(t<=360){
           g_loa=6; //右前方远处
        }
        if((t>360)&&(t<720)){
            g_loa=7;//右前方
        }
        if(t>=720){
            g_loa=8;//右前方很近
        }
    }
    float score = item->score * MULTIPLE_OF_EXPANSION / SCORE_MAX;
    SAMPLE_PRT("audio_player:item score:%f, cls:%d \n",item->score, item->cls);
    if(item->score > 0.5){
    if ((g_obj != item->cls)||(g_loaa !=g_loa)) {
        g_obj = item->cls;
        g_loaa = g_loa;
        g_num=g_obj*10+g_loaa;
        SAMPLE_PRT("audio_player:local:%d \n",g_loaa);
        SAMPLE_PRT("audio_player:num:%d \n",g_num);
     
        AudioTest(g_num, -1);   
        g_loa=0;
    }
    }
    g_count = 0;
}
/*
static int g_n = 0;
static HI_VOID PlayAudiodistance(const int numbers)
{
    const int *number = &numbers;
    if(g_n == number){
       break;
    }else{
        if(number==1){
            g_n=number;
            AudioTest(9, -1);
        }
       }          
}*/

static HI_VOID PlayAudiodistance(void)
{
    AudioTest(69, -1);
}
static HI_VOID* GetAudioFileName(HI_VOID* arg)
{
    DetectObjInfo resBuf = {0};
    int q0=0;
    int ret=0;
    int rett=0;
    q0=GetDistanceNumber();
    
    while (g_bAudioProcessStopSignal == false) {
        //rett = FdReadMsg(g_stmChn.in, &q0, sizeof(int));
        //if (rett == sizeof(int)){
        ret = FdReadMsg(g_stmChn.in, &resBuf, sizeof(DetectObjInfo));
        //SAMPLE_PRT("PlayAudio(distance) q0=%d \n",q0);
            if(q0==1){
                PlayAudiodistance();
                SAMPLE_PRT("PlayAudio(distance) ok");
                return NULL;
            }
            else{
                if (ret == sizeof(DetectObjInfo)) 
                {
                   SAMPLE_PRT("PlayAudio(resBuf) score:%f,cls:%d \n",resBuf.score,resBuf.cls);
                   PlayAudio(resBuf);
                   }
                }
    }
    return NULL;
}
#define HI_TO_STR(c) 
static const char YOLO2_HAND_DETECT_RESNET_CLASSIFY[] = "{"
    "\"uuid\": " PLUG_UUID ","
    "\"desc\": " PLUG_DESC ","
    "\"frmWidth\": " HI_TO_STR(FRM_WIDTH) ","
    "\"frmHeight\": " HI_TO_STR(FRM_HEIGHT) ","
    "\"butt\": 0"
"}";

static const char* Yolo2HandDetectResnetClassifyProf(void)
{
    return YOLO2_HAND_DETECT_RESNET_CLASSIFY;
}

/*
 * 加载手部检测和手势分类模型
 * Load hand detect and classify model
 */
HI_S32 Yolo2HandDetectResnetClassifyLoad(uintptr_t* model,OsdSet* osds)
{
    SAMPLE_SVP_NNIE_CFG_S *self = NULL;
    HI_S32 ret;

    g_osdsGesture = osds;
    HI_ASSERT(g_osdsGesture);
    g_osd0Gesture = OsdsCreateRgn(g_osdsGesture);
    HI_ASSERT(g_osd0Gesture >= 0);

    ret = CnnCreate(&self, MODEL_FILE_GESTURE);
    *model = ret < 0 ? 0 : (uintptr_t)self;
    HandDetectInit(); // Initialize the hand detection model
    SAMPLE_PRT("Load hand detect claasify model success\n");

    //音频启动启动启动
    if (GetCfgBool("audio_player:support_audio", true)) {
        
		ret = SkPairCreate(&g_stmChn);
		HI_ASSERT(ret == 0);
		if (pthread_create(&g_thrdId, NULL, GetAudioFileName, NULL) < 0) {
			HI_ASSERT(0);
		}
		g_supportAudio = 1;
        SAMPLE_PRT("audio_player:support_audio\n");
	}

    /*
     * Uart串口初始化
     * Uart open init
     */
    uartFd = UartOpenInit();
    if (uartFd < 0) {
        printf("uart1 open failed\r\n");
    } else {
        printf("uart1 open successed\r\n");
    }
    return ret;
}

void getdistance(void){
   // unsigned char buf[BUFFER_SIZE1];
    //unsigned int len = BUFFER_SIZE1; 
     char buf[BUFFER_SIZE1];
     int len = BUFFER_SIZE1; 
    int q=0;
    q = HisignallingGetDistance(uartFd, buf, len);
    printf("turn on or turn off:%d \n",q);
}


static int q1=0;
int GetDistanceNumber(void){  
    static char buf0[BUFFER_SIZE1];
    static int len0 = BUFFER_SIZE1; 
    int q0=0;
    q0 = HisignallingGetDistance(uartFd, buf0, len0);
    printf("HisignallingGetDistance q0:%d \n",q0);
    return q0;
}
/*
 * 卸载手部检测和手势分类模型
 * Unload hand detect and classify model
 */
HI_S32 Yolo2HandDetectResnetClassifyUnload(uintptr_t model)
{
    CnnDestroy((SAMPLE_SVP_NNIE_CFG_S*)model);
    //音频卸载卸载卸载
    if (g_osdsGesture) {
        OsdsClear(g_osdsGesture);
        g_osdsGesture = NULL;
        SAMPLE_PRT("Unload g_osdsGesture OK!\n");
    }
    if (g_supportAudio == 1) {
		SkPairDestroy(&g_stmChn);
		pthread_join(g_thrdId, NULL);
        SAMPLE_PRT("Unload pthread_join OK!\n");
	}

    HandDetectExit(); // Uninitialize the hand detection model
    close(uartFd);
    SAMPLE_PRT("Unload hand detect claasify model success\n");

    return 0;
}

/*
 * 获得最大的手
 * Get the maximum hand
 */
static HI_S32 GetBiggestHandIndex(RectBox boxs[], int detectNum)
{
    HI_S32 handIndex = 0;
    HI_S32 biggestBoxIndex = handIndex;
    HI_S32 biggestBoxWidth = boxs[handIndex].xmax - boxs[handIndex].xmin + 1;
    HI_S32 biggestBoxHeight = boxs[handIndex].ymax - boxs[handIndex].ymin + 1;
    HI_S32 biggestBoxArea = biggestBoxWidth * biggestBoxHeight;

    for (handIndex = 1; handIndex < detectNum; handIndex++) {
        HI_S32 boxWidth = boxs[handIndex].xmax - boxs[handIndex].xmin + 1;
        HI_S32 boxHeight = boxs[handIndex].ymax - boxs[handIndex].ymin + 1;
        HI_S32 boxArea = boxWidth * boxHeight;
        if (biggestBoxArea < boxArea) {
            biggestBoxArea = boxArea;
            biggestBoxIndex = handIndex;
        }
        biggestBoxWidth = boxs[biggestBoxIndex].xmax - boxs[biggestBoxIndex].xmin + 1;
        biggestBoxHeight = boxs[biggestBoxIndex].ymax - boxs[biggestBoxIndex].ymin + 1;
    }

    if ((biggestBoxWidth == 1) || (biggestBoxHeight == 1) || (detectNum == 0)) {
        biggestBoxIndex = -1;
    }

    return biggestBoxIndex;
}

/*
    Add gesture recognition information next to the rectangle
    给方框加识别信息
*/
/*
#define TINY_BUF_SIZE 128
static void HandDetectAddTxt(const RectBox box, const RecogNumInfo resBuf, uint32_t color)
{
    HI_OSD_ATTR_S osdRgn;
    char osdTxt[TINY_BUF_SIZE]; 
    HI_ASSERT(g_osdsGesture);
    Flag1++;
    sum += resBuf.num;  
    if(Flag1 == 3){
    New_Num = sum/3;
    if(New_Num < 0.9){
        gesture_name = "Cat";
        //usbUartSendRead(uart_fd, CAT);
         // usleep(100*1000);
    }else{
        gesture_name = "Gog";
        //usbUartSendRead(uart_fd, DOG);
       // usleep(100*1000);
    }   
    // switch (resBuf.num) {
    //     case 0u:
    //         gesture_name = "gesture cat";
    //         usbUartSendRead(uart_fd, CAT);
    //         break;
    //     case 1u:
    //         gesture_name = "gesture gog";
    //         usbUartSendRead(uart_fd, DOG);
    //         usleep(100*1000);
    //         break;
    //     default:
    //         gesture_name = "background";
    //         usbUartSendRead(uart_fd, UNKNOWN);
    //         usleep(100*1000);
    //         break;
    // }
    uint32_t score = (resBuf.score) * HI_PER_BASE / SCORE_MAX;
	int res = snprintf_s(osdTxt, sizeof(osdTxt), sizeof(osdTxt) - 1, "%.2f_%s,%d %%",New_Num, gesture_name, score);
	HI_ASSERT(res > 0);
	int osdId = OsdsCreateRgn(g_osdsGesture);
	HI_ASSERT(osdId >= 0);

    int x = box.xmin / HI_OVEN_BASE * HI_OVEN_BASE;
    int y = (box.ymin - 30) / HI_OVEN_BASE * HI_OVEN_BASE; // 30: empirical value
    if (y < 0) {
        LOGD("osd_y < 0, y=%d\n", y);
        OsdsDestroyRgn(g_osdsGesture, osdId);
    } else {
        //TxtRgnInit(&osdRgn, osdTxt, x, y, color, OSD_FONT_WIDTH, OSD_FONT_HEIGHT);
        TxtRgnInit(&osdRgn, osdTxt, x, y, color);
        OsdsSetRgn(g_osdsGesture, osdId, &osdRgn);
    }
    Flag1 = 0;
    New_Num = 0;
    sum = 0;
    }
}*/

/*DetectObjInfo
 * 手势识别信息
 * Hand gesture recognition info
 */
static void HandDetectFlag(const DetectObjInfo obja)
{
    const DetectObjInfo *ba = &obja;
    float score = ba->score;

    //if (score > SCORE_MAX){
    HI_CHAR *gestureName = NULL;
    HI_CHAR *positionName = NULL;
    int s,t=0;
    s=(obja.box.xmax+obja.box.xmin)/2;
    t=(obja.box.ymax+obja.box.ymin)/2;
    int b=0;
    if((s>640)&&(s<1280)){
        if(t<=360){
           b=0; //正前方远处
        }
        if((t>360)&&(t<720)){
            b=1;//正前方
        }
        if(t>=720){
            b=2;//正前方很近
        }
    }
    if(s<=640){
        if(t<=360){
           b=3; //左前方远处
        }
        if((t>360)&&(t<720)){
            b=4;//左前方
        }
        if(t>=720){
            b=5;//左前方很近
        }
    }
    if(s>=1280){
        if(t<=360){
           b=6; //右前方远处
        }
        if((t>360)&&(t<720)){
            b=7;//右前方
        }
        if(t>=720){
            b=8;//右前方很近
        }
    }

    switch (obja.cls) {
        case 1u:
            gestureName = "circle";
            //UartSendRead(uartFd, FistGesture); // 检测到障碍物
            SAMPLE_PRT("----object----:%s\n", gestureName);
            switch(b){
                case 0u:
                positionName = "far front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 1u:
                positionName = "front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 2u:
                positionName = "near front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 3u:
                positionName = "far left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 4u:
                positionName = "left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 5u:
                positionName = "near left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 6u:
                positionName = "far right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 7u:
                positionName = "right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 8u:
                positionName = "near right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
            }
            break;
        case 2u:
            gestureName = "ashcan";
            //UartSendRead(uartFd, ForefingerGesture); // 食指手势
            SAMPLE_PRT("----object----:%s\n", gestureName);
            switch(b){
                case 0u:
                positionName = "far front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 1u:
                positionName = "front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 2u:
                positionName = "near front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 3u:
                positionName = "far left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 4u:
                positionName = "left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 5u:
                positionName = "near left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 6u:
                positionName = "far right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 7u:
                positionName = "right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 8u:
                positionName = "near right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
            }
            break;
        case 3u:
            gestureName = "pole";
            //UartSendRead(uartFd, OkGesture); // OK手势
            SAMPLE_PRT("----object----:%s\n", gestureName);
            switch(b){
                case 0u:
                positionName = "far front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 1u:
                positionName = "front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 2u:
                positionName = "near front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 3u:
                positionName = "far left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 4u:
                positionName = "left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 5u:
                positionName = "near left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 6u:
                positionName = "far right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 7u:
                positionName = "right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 8u:
                positionName = "near right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
            }
            break;
        case 4u:
            gestureName = "person";
            //UartSendRead(uartFd, PalmGesture); // 手掌手势
            SAMPLE_PRT("----object----:%s\n", gestureName);
            switch(b){
                case 0u:
                positionName = "far front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 1u:
                positionName = "front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 2u:
                positionName = "near front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 3u:
                positionName = "far left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 4u:
                positionName = "left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 5u:
                positionName = "near left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 6u:
                positionName = "far right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 7u:
                positionName = "right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 8u:
                positionName = "near right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
            }
            break;
        case 5u:
            gestureName = "non-motor";
            //UartSendRead(uartFd, YesGesture); // yes手势
            SAMPLE_PRT("----object----:%s\n", gestureName);
           switch(b){
                case 0u:
                positionName = "far front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 1u:
                positionName = "front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 2u:
                positionName = "near front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 3u:
                positionName = "far left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 4u:
                positionName = "left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 5u:
                positionName = "near left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 6u:
                positionName = "far right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 7u:
                positionName = "right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 8u:
                positionName = "near right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
            }
            break;
        case 6u:
            gestureName = "obstacle";
            //UartSendRead(uartFd, ForefingerAndThumbGesture); // 食指 + 大拇指
            SAMPLE_PRT("----object----:%s\n", gestureName);
           switch(b){
                case 0u:
                positionName = "far front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 1u:
                positionName = "front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 2u:
                positionName = "near front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 3u:
                positionName = "far left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 4u:
                positionName = "left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 5u:
                positionName = "near left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 6u:
                positionName = "far right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 7u:
                positionName = "right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 8u:
                positionName = "near right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
            }
            break;
        default:
            gestureName = "unknow others";
            //UartSendRead(uartFd, InvalidGesture); // 无效值
            SAMPLE_PRT("----object----:%s\n", gestureName);
           switch(b){
                case 0u:
                positionName = "far front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 1u:
                positionName = "front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 2u:
                positionName = "near front";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 3u:
                positionName = "far left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 4u:
                positionName = "left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 5u:
                positionName = "near left";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 6u:
                positionName = "far right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 7u:
                positionName = "right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
                case 8u:
                positionName = "near right";
                SAMPLE_PRT("----position----:%s\n", positionName);
                break;
            }
            break;
    }
    SAMPLE_PRT("object detect success!\n");
    //}
}



/*
 * 手部检测和手势分类推理
 * Hand detect and classify calculation
 */
HI_S32 Yolo2HandDetectResnetClassifyCal(uintptr_t model, VIDEO_FRAME_INFO_S *srcFrm, VIDEO_FRAME_INFO_S *dstFrm,HI_CHAR** resJson)
{
    SAMPLE_SVP_NNIE_CFG_S *self = (SAMPLE_SVP_NNIE_CFG_S*)model;
    HI_S32 resLen = 0;
    int objNum;
    int ret;
    int num = 0;

    ret = FrmToOrigImg((VIDEO_FRAME_INFO_S*)srcFrm, &img);
    SAMPLE_CHECK_EXPR_RET(ret != HI_SUCCESS, ret, "hand detect for YUV Frm to Img FAIL, ret=%#x\n", ret);

    objNum = HandDetectCal(&img, objs); // Send IMG to the detection net for reasoning
    for (int i = 0; i < objNum; i++) {
        cnnBoxs[i] = objs[i].box;
        RectBox *box = &objs[i].box;
        RectBoxTran(box, HAND_FRM_WIDTH, HAND_FRM_HEIGHT,
            dstFrm->stVFrame.u32Width, dstFrm->stVFrame.u32Height);
        SAMPLE_PRT("yolo2_out: {%d, %d, %d, %d}\n", box->xmin, box->ymin, box->xmax, box->ymax);
        //xmax MAX为1920，ymax MAX为1080 
        boxs[i] = *box;
    }
    biggestBoxIndex = GetBiggestHandIndex(boxs, objNum);
    SAMPLE_PRT("biggestBoxIndex:%d, objNum:%d\n", biggestBoxIndex, objNum);

    /*
     * 当检测到对象时，在DSTFRM中绘制一个矩形
     * When an object is detected, a rectangle is drawn in the DSTFRM
     */
   
    if (biggestBoxIndex >= 0) {
        objBoxs[0] = boxs[biggestBoxIndex];
        RectBox *box = &objBoxs[0];
        SAMPLE_PRT("biggestBox object:%d, score:%f, cls:%d \n", biggestBoxIndex, objs[biggestBoxIndex].score, objs[biggestBoxIndex].cls);
        //if(objs[biggestBoxIndex].score>0.6){
        if((box->xmin>= 0)&&( box->ymin >= 0)){
        if((box->xmax <= 1920)&&( box->ymax <= 1080)){
            int a,c=0;
            a=(box->xmax)-(box->xmin);
            c=(box->ymax)-(box->ymin);
        if((a>=20)&&(c>=20)){
        if((a<=1300)&&(c<=700)){
        MppFrmDrawRects(dstFrm, objBoxs, 1, RGB888_GREEN, DRAW_RETC_THICK); // Target hand objnum is equal to 1
        }}}}
        //}
    
        for (int j = 0; (j < objNum) && (objNum > 1); j++) {
            if (j != biggestBoxIndex) {
                remainingBoxs[num++] = boxs[j];
                RectBox *d = &remainingBoxs[num++];
                SAMPLE_PRT("object:%d, score:%f\n", j, objs[j].score);
            //if(objs[j].score>SCORE_MAX){
                if((d->xmin>= 0)&&( d->ymin >= 0)){
                if((d->xmax <= 1920)&&( d->ymax <= 1080)){
                int a,c=0;
                    a=(d->xmax)-(d->xmin);
                    c=(d->ymax)-(d->ymin);
                if((a>=20)&&(c>=20)){
                if((a<=1300)&&(c<=700)){
                /*
                * 其他手objnum等于objnum -1
                * Others hand objnum is equal to objnum -1
                */
                MppFrmDrawRects(dstFrm, remainingBoxs, objNum - 1, RGB888_RED, DRAW_RETC_THICK);
                }}}} 
                //}
                }
        }

    /*
    * 裁剪出来的图像通过预处理送分类网进行推理
    * The cropped image is preprocessed and sent to the classification network for inference
    */
    
    ret = ImgYuvCrop(&img, &imgIn, &cnnBoxs[biggestBoxIndex]);
    SAMPLE_CHECK_EXPR_RET(ret < 0, ret, "ImgYuvCrop FAIL, ret=%#x\n", ret);

    if ((imgIn.u32Width >= WIDTH_LIMIT) && (imgIn.u32Height >= HEIGHT_LIMIT)) {
        COMPRESS_MODE_E enCompressMode = srcFrm->stVFrame.enCompressMode;
        ret = OrigImgToFrm(&imgIn, &frmIn);
        frmIn.stVFrame.enCompressMode = enCompressMode;
        // SAMPLE_PRT("crop u32Width = %d, img.u32Height = %d\n", imgIn.u32Width, imgIn.u32Height);
        ret = MppFrmResize(&frmIn, &frmDst, IMAGE_WIDTH, IMAGE_HEIGHT);
        ret = FrmToOrigImg(&frmDst, &imgDst);
        //ret = CnnCalImg(self,  &imgDst, numInfo, sizeof(numInfo) / sizeof((numInfo)[0]), &resLen);
        //SAMPLE_CHECK_EXPR_RET(ret < 0, ret, "CnnCalImg FAIL, ret=%#x\n", ret);
        //HI_ASSERT(resLen <= sizeof(numInfo) / sizeof(numInfo[0]));

        HandDetectFlag(objs[biggestBoxIndex]);

        //HandDetectAddTxt(cnnBoxs[biggestBoxIndex], numInfo[0], RGB888_RED);
        MppFrmDestroy(&frmDst);
    }
    IveImgDestroy(&imgIn);
    }

    //HI_CHAR *jsonBuf = CnnGestureClassifyToJson(numInfo, resLen);
    //*resJson = jsonBuf;

    getdistance();
    q1 = GetDistanceNumber();
    
    SAMPLE_PRT("q1=%d\n",q1);
    if(q1==1){
        int len2=FdWriteMsg(g_stmChn.out, &q1, sizeof(int));
        if (len2 != sizeof(int)) {
			SAMPLE_PRT("FdWriteMsg distance FAIL\n");
		}
    }else{
        
        if ((g_supportAudio == 1) && (biggestBoxIndex >= 0) ) {
		if (FdWriteMsg(g_stmChn.out, &objs[biggestBoxIndex], sizeof(DetectObjInfo)) != sizeof(DetectObjInfo)) {
			SAMPLE_PRT("FdWriteMsg objs FAIL\n");
		}
	}
    
    return ret;
}
#define HI_PCHAR char*
typedef struct AiPlug {
    const HI_PCHAR (*Prof)(void);
    int (*Load)(uintptr_t* model, OsdSet* osds);
    int (*Unload)(uintptr_t model);
    int (*Cal)(uintptr_t model, VIDEO_FRAME_INFO_S* srcFrm,
        VIDEO_FRAME_INFO_S* resFrm, char** resJson);
    int (*StartSvc)(void);
    int (*StopSvc)(void);
} AiPlug;

static const AiPlug G_HAND_CLASSIFY_ITF = {
    .Prof = Yolo2HandDetectResnetClassifyProf,
    .Load = Yolo2HandDetectResnetClassifyLoad,
    .Unload = Yolo2HandDetectResnetClassifyUnload,
    .Cal = Yolo2HandDetectResnetClassifyCal,
};
#define AI_PLUG_MAGIC       0x3D2E837B 
#define AI_PLUG_EXTNAME     "plug" 
const AiPlug* AiPlugItf(uint32_t* magic)
{
    if (magic) {
        *magic = AI_PLUG_MAGIC;
    }

    return (AiPlug*)&G_HAND_CLASSIFY_ITF;
}
const AiPlug* AiPlugItf(uint32_t* magic);
typedef const AiPlug* (*AIPlugItfFunc)(uint32_t* magic);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
