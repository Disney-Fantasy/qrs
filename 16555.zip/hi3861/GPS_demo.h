#ifndef GPS_DEMO_H
#define GPS_DEMO_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include "GPS_demo.h"
//#include <string>

//#include "iot_gpio_ex.h"
//#include "ohos_init.h"
//#include "cmsis_os2.h"
//#include "iot_gpio.h"
//#include "iot_uart.h"
//#include "hi_uart.h"
//#include "iot_watchdog.h"
//#include "iot_errno.h"
#include "app_demo_iot.h"

/***************************************************\
*GPS NMEA-0183协议重要参数结构体定义
*卫星信息
/*
typedef struct
{
	uint8_t get_gps_ok:1;
	char N_S;	//北纬/南纬,N:北纬;S:南纬	
	char E_W;   //东经/西经,E:东经;W:西经	
	double latitude_ns;	//纬度   分扩大100000倍，实际要除以100000
	double longitude_ew;//经度 分扩大100000倍,实际要除以100000
    //int altitude;			 	            //海拔高度,放大了10倍,实际除以10.单位:0.1m	
}gps_msg;
//extern gps_msg gps;
//GPS传感器数据类型定义 

typedef struct
{
	uint8_t get_gps_ok:1;
    char  Latitude[20];                //纬度
	char  Longitude[20];				//经度	
} GPS_Data_TypeDef;
*/
//extern GPS_Data_TypeDef gps_dddd;
void Uart1GpioInit(void);
void UartTask();
//GPS_Data_TypeDef *UartTask(void);
//void UartExampleEntry(void);
/*
extern uint8_t get_gps_ok;
extern float latitude;
extern float longitude;
*/
#endif  // GPS_DEMO_H