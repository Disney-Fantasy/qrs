/*
 * Copyright (c) 2022 HiSilicon (Shanghai) Technologies CO., LIMITED.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <string.h>
#include "GPS_demo.h"

#include "iot_config.h"
#include "iot_main.h"
#include "iot_profile.h"
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "wifi_connecter.h"
#include "iot_gpio_ex.h"
#include "iot_gpio.h"
#include "iot_watchdog.h"
#include "cjson_init.h"
#include "hi_stdlib.h"
#include "app_demo_iot.h"
//#include "uart_control.h"
//#include <json-c/json.h>
extern uint8_t get_mpu = 1;
/* attribute initiative to report */
#define TAKE_THE_INITIATIVE_TO_REPORT
/* oc request id */
#define CN_COMMAND_INDEX                    "commands/request_id="
/* oc report HiSpark attribute */


#define TASK_SLEEP_1000MS (1000)

extern uint8_t get_gps_ok;
extern float latitude;
extern float longitude;
// /< this is the callback function, set to the mqtt, and if any messages come, it will be called
// /< The payload here is the json string

static void DemoMsgRcvCallBack(int qos, char *topic, char *payload)
{
    const char *requesID;
    char *tmp;
    IoTCmdResp resp;
    printf("RCVMSG:QOS:%d TOPIC:%s PAYLOAD:%s\r\n", qos, topic, payload);
    // app 下发的操作 //
    //TrafficLightMsgRcvCallBack(payload);
    tmp = strstr(topic, CN_COMMAND_INDEX);
    if (tmp != NULL) {
        // /< now you could deal your own works here --THE COMMAND FROM THE PLATFORM
        // /< now er roport the command execute result to the platform
        requesID = tmp + strlen(CN_COMMAND_INDEX);
        resp.requestID = requesID;
        resp.respName = NULL;
        resp.retCode = 0;   ////< which means 0 success and others failed
        resp.paras = NULL;
        (void)IoTProfileCmdResp(CONFIG_DEVICE_PWD, &resp);
    }
}

/* traffic light:1.control module */
/*
void IotPublishSample(GPS_Data_TypeDef res)
{

    IoTProfileService service_gps;
    IoTProfileKV property_gps1;
    IoTProfileKV property_gps2;
    //IoTProfileService service_far;
    //IoTProfileService property_
    printf("GPS signal\r\n");
    
    memset_s(&property_gps1, sizeof(property_gps1), 0, sizeof(property_gps1));
    memset_s(&property_gps2, sizeof(property_gps2), 0, sizeof(property_gps2));
   
    property_gps1.key = "LATITUDE";
    property_gps1.type = EN_IOT_DATATYPE_STRING;
    property_gps1.nxt=&property_gps2;
    property_gps2.key = "LONGITUDE";
    property_gps2.type = EN_IOT_DATATYPE_STRING;
    property_gps2.nxt=NULL;
    //UartExampleEntry();
    //printf("GPS DATA: %0.2lf %c; %0.2lf %c\n",gps.latitude_ns,gps.N_S,gps.longitude_ew,gps.E_W);
    printf("GPS DATA: %s;%s\n",res.Latitude,res.Longitude);
    printf("get_gps_ok:%d\n",res.get_gps_ok);
    
    if(res.get_gps_ok == 1) {
        strcpy(property_gps1.value,res.Latitude);
        strcpy(property_gps2.value,res.Longitude);
        //sprintf(property_gps1.value,"%s",gps.latitude_ns);
        //sprintf(property_gps2.value,"%s",gps.longitude_ew);

    
    }
    if(res.get_gps_ok==0){
        
        property_gps1.value = "FAULT";
        property_gps2.value = "FAULT";
        
    }
    else{
        property_gps1.value = "NONE";
        property_gps2.value = "NONE";
    }
    memset_s(&service_gps, sizeof(service_gps), 0, sizeof(service_gps)); 
    service_gps.serviceID = "GPS_MESSAGE";
    service_gps.nxt=NULL;
    service_gps.eventTime=NULL;
    service_gps.serviceProperty = &property_gps1;
    IoTProfilePropertyReport(CONFIG_DEVICE_ID, &service_gps);
}
*/
void IotPublishSample(void)
{

    IoTProfileService service_gps;
    IoTProfileKV property_gps1;
    IoTProfileKV property_gps2;
    IoTProfileService service_mpu;
    IoTProfileKV property_mpu;
    printf("GPS signal\r\n");
    //printf("GPS:%d N; %d E\n",latitude,longitude);
    memset_s(&property_gps1, sizeof(property_gps1), 0, sizeof(property_gps1));
    memset_s(&property_gps2, sizeof(property_gps2), 0, sizeof(property_gps2));
    memcpy_s(&property_mpu,sizeof(property_mpu),0,sizeof(property_mpu));
    property_gps1.key = "LATITUDE";
    property_gps1.type = EN_IOT_DATATYPE_STRING;
    property_gps1.nxt=&property_gps2;
    property_gps2.key = "LONGITUDE";
    property_gps2.type = EN_IOT_DATATYPE_STRING;
    //property_gps2.nxt=NULL;
   
    
    //property_mpu.nxt=NULL;
    //UartExampleEntry();
    //printf("GPS DATA: %0.2lf %c; %0.2lf %c\n",gps.latitude_ns,gps.N_S,gps.longitude_ew,gps.E_W);
    //printf("GPS DATA: %s;%s\n",res->Latitude,res->Longitude);
    //printf("get_gps_ok:%d\n",res->get_gps_ok);
    //if(get_gps_ok==1) {
        
        char floatString[32];  // 假设足够大的字符数组来存储浮点数的字符串表示
        sprintf(floatString, "%.2f", latitude);// 将浮点数转换为字符串，并存储在 floatString 中
        property_gps1.value = malloc(sizeof(char) * (strlen(floatString) + 1));
        if (property_gps1.value == NULL) {
        // 内存分配失败的处理
        perror("Memory allocation failed");
    }   strcpy(property_gps1.value, floatString); // 将转换后的字符串复制到 property.value  
        printf("%s\n", property_gps1.value);// 打印 property.value 的值以验证是否成功赋值
        
        sprintf(floatString, "%.2f", longitude);// 将浮点数转换为字符串，并存储在 floatString 中
        property_gps2.value = malloc(sizeof(char) * (strlen(floatString) + 1));
        if (property_gps2.value == NULL) {
        // 内存分配失败的处理
        perror("Memory allocation failed");
    }   strcpy(property_gps2.value, floatString); // 将转换后的字符串复制到 property.value  
        printf("%s\n", property_gps2.value);// 打印 property.value 的值以验证是否成功赋值
        
        //snprintf(property_gps1.value, sizeof(property_gps1.value), "%.2f", latitude);
        //snprintf(property_gps2.value, sizeof(property_gps2.value), "%.2f", longitude);
        
    //}
    //else{
    //    property_gps1.value = "NONE";
    //    property_gps2.value = "NONE";
    //}
    //if(res->get_gps_ok==0){
       
    //}
    memset_s(&service_gps, sizeof(service_gps), 0, sizeof(service_gps)); 
    memset_s(&service_mpu,sizeof(service_mpu),0,sizeof(service_mpu));
    service_gps.serviceID = "GPS_MESSAGE";
    //service_gps.eventTime=NULL;
    service_gps.serviceProperty = &property_gps1;
   
    IoTProfilePropertyReport(CONFIG_DEVICE_ID, &service_gps);
    free(property_gps1.value);
    free(property_gps2.value);
        
}
// /< this is the demo main task entry,here we will set the wifi/cjson/mqtt ready ,and
// /< wait if any work to do in the while
static void DemoEntry(void)
{
    ConnectToHotspot();//连接设备到wifi热点
    //RedLedInit();//初始化红色led
    CJsonInit();//json库初始化以处理json数据
    IoTMain();//建立MQTT连接
    IoTSetMsgCallback(DemoMsgRcvCallBack);
    TaskMsleep(30000); // 30000 = 3s连接华为云
    //UartExampleEntry();
    //GPS_Data_TypeDef *res = UartTask();
    //UartTask();
/* 主动上报 */

    while (1) {
        // here you could add your own works here--we report the data to the IoTplatform
        
        IotPublishSample();//循环发布消息
        TaskMsleep(TASK_SLEEP_1000MS);
        // know we report the data to the iot platform
       
    }
}


// This is the demo entry, we create a task here, and all the works has been done in the demo_entry
#define CN_IOT_TASK_STACKSIZE  0x1000
#define CN_IOT_TASK_PRIOR 28
#define CN_IOT_TASK_NAME "IOTDEMO"
static void AppDemoIot(void)
{
    osThreadAttr_t attr;
    IoTWatchDogDisable();
    attr.name = "IOTDEMO";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 50*1024;
    //attr.stack_size = CN_IOT_TASK_STACKSIZE;
    attr.priority = CN_IOT_TASK_PRIOR;

    if (osThreadNew((osThreadFunc_t)DemoEntry, NULL, &attr) == NULL) {
        printf("[TrafficLight] Failed to create IOTDEMO!\n");
    }
}

SYS_RUN(AppDemoIot);